package es.server.greenleaf;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.NamespacedKey;
import java.util.*;

public final class GreenLeaf extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey kindKey, cropKey;
    private final Set<String> crops = new HashSet<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        kindKey = new NamespacedKey(this, "item_kind");
        cropKey = new NamespacedKey(this, "greenleaf_crop");
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("weed")).setExecutor(this);
        loadCrops();
        getLogger().info("GreenLeaf activado. Usa /weed para administrar items.");
        Bukkit.addRecipe(new ShapelessRecipe(new NamespacedKey(this, "joint_recipe"), joint(1))
                .addIngredient(Material.GREEN_DYE).addIngredient(Material.PAPER));
    }
    private String loc(Block b) { return b.getWorld().getName()+":"+b.getX()+":"+b.getY()+":"+b.getZ(); }
    private void loadCrops() { crops.addAll(getConfig().getStringList("planted-crops")); }
    private void saveCrops() { getConfig().set("planted-crops", new ArrayList<>(crops)); saveConfig(); }

    private ItemStack item(Material material, String kind, String name, int customModel) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.GREEN + name);
        meta.setLore(List.of(ChatColor.GRAY + "GreenLeaf", ChatColor.DARK_GRAY + "Contenido ficticio de roleplay"));
        meta.getPersistentDataContainer().set(kindKey, PersistentDataType.STRING, kind);
        // CustomModelData se usa para enlazar las texturas del resource pack.
        meta.setCustomModelData(customModel);
        stack.setItemMeta(meta);
        return stack;
    }
    private String kind(ItemStack s) {
        if (s == null || !s.hasItemMeta()) return "";
        return s.getItemMeta().getPersistentDataContainer().getOrDefault(kindKey, PersistentDataType.STRING, "");
    }
    private ItemStack seeds(int n) { ItemStack s=item(Material.WHEAT_SEEDS,"seeds","Semillas de cannabis (roleplay)",1001); s.setAmount(n); return s; }
    private ItemStack leaf(int n) { ItemStack s=item(Material.GREEN_DYE,"leaf","Hoja seca",1002); s.setAmount(n); return s; }
    private ItemStack joint(int n) { ItemStack s=item(Material.STICK,"joint","Porro",1003); s.setAmount(n); return s; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Este comando solo puede usarlo un jugador."); return true; }
        if (!p.hasPermission("greenleaf.admin")) { p.sendMessage(ChatColor.RED+"No tienes permiso."); return true; }
        if (args.length == 0) { p.sendMessage(ChatColor.GREEN+"/weed semillas [cantidad] | hoja [cantidad] | papel [cantidad] | porro [cantidad]"); return true; }
        int n=1; if (args.length>1) try { n=Math.max(1,Math.min(64,Integer.parseInt(args[1]))); } catch(NumberFormatException ignored) {}
        switch(args[0].toLowerCase(Locale.ROOT)) {
            case "semillas" -> p.getInventory().addItem(seeds(n));
            case "hoja" -> p.getInventory().addItem(leaf(n));
            case "papel" -> { ItemStack paper=new ItemStack(Material.PAPER,n); p.getInventory().addItem(paper); }
            case "porro" -> p.getInventory().addItem(joint(n));
            case "pack" -> p.sendMessage(ChatColor.YELLOW+"El resource pack está en la carpeta resourcepack/ del proyecto.");
            default -> p.sendMessage(ChatColor.RED+"Uso: /weed semillas|hoja|papel|porro [cantidad]");
        }
        return true;
    }


    @EventHandler(ignoreCancelled=true)
    public void validateCraft(org.bukkit.event.inventory.PrepareItemCraftEvent e) {
        if (!(e.getRecipe() instanceof ShapelessRecipe recipe)) return;
        if (!recipe.getKey().equals(new NamespacedKey(this, "joint_recipe"))) return;
        boolean hasLeaf=false, hasPaper=false;
        for (ItemStack ingredient : e.getInventory().getMatrix()) {
            if (kind(ingredient).equals("leaf")) hasLeaf=true;
            else if (ingredient != null && ingredient.getType()==Material.PAPER) hasPaper=true;
            else if (ingredient != null && ingredient.getType()!=Material.AIR) {
                e.getInventory().setResult(null); return;
            }
        }
        if (!hasLeaf || !hasPaper) e.getInventory().setResult(null);
    }

    @EventHandler(ignoreCancelled=true)
    public void onPlant(PlayerInteractEvent e) {
        if (e.getAction()!=Action.RIGHT_CLICK_BLOCK || e.getClickedBlock()==null) return;
        ItemStack hand=e.getItem();
        if (!kind(hand).equals("seeds")) return;
        Block soil=e.getClickedBlock();
        if (soil.getType()!=Material.FARMLAND) return;
        Block crop=soil.getRelative(0,1,0);
        if (!crop.getType().isAir()) return;
        crop.setType(Material.WHEAT);
        if (crop.getBlockData() instanceof Ageable age) { age.setAge(0); crop.setBlockData(age); }
        crops.add(loc(crop)); saveCrops();
        e.setCancelled(true);
        consumeOne(e.getPlayer(), hand);
        e.getPlayer().sendMessage(ChatColor.GREEN+"Has plantado cannabis. Deja que madure y cosecha la planta.");
        crop.getWorld().playSound(crop.getLocation(), Sound.ITEM_CROP_PLANT, 0.8f, 1.1f);
    }

    @EventHandler(ignoreCancelled=true)
    public void onHarvest(BlockBreakEvent e) {
        Block b=e.getBlock(); String id=loc(b);
        if (!crops.contains(id)) return;
        if (!(b.getBlockData() instanceof Ageable age) || age.getAge()<age.getMaximumAge()) {
            e.setCancelled(true); e.getPlayer().sendMessage(ChatColor.YELLOW+"La planta aún no está madura."); return;
        }
        e.setDropItems(false); crops.remove(id); saveCrops();
        b.getWorld().dropItemNaturally(b.getLocation(), leaf(1));
        if (Math.random()<getConfig().getDouble("crop.bonus-seed-chance",0.35))
            b.getWorld().dropItemNaturally(b.getLocation(), seeds(1));
        b.getWorld().playSound(b.getLocation(), Sound.BLOCK_GRASS_BREAK, 1f, 0.8f);
        e.getPlayer().sendMessage(ChatColor.GREEN+"Cosecha recogida.");
    }

    @EventHandler(ignoreCancelled=true)
    public void onUse(PlayerInteractEvent e) {
        if (e.getAction()!=Action.RIGHT_CLICK_AIR && e.getAction()!=Action.RIGHT_CLICK_BLOCK) return;
        Player p=e.getPlayer(); ItemStack hand=e.getItem();
        if (kind(hand).equals("joint")) {
            e.setCancelled(true);
            int nausea=Math.max(1,getConfig().getInt("effects.nausea-seconds",18))*20;
            int speed=Math.max(1,getConfig().getInt("effects.speed-seconds",25))*20;
            int amp=Math.max(0,Math.min(4,getConfig().getInt("effects.speed-amplifier",2)));
            p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,nausea,0,true,true,true));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,speed,amp,true,true,true));
            int count=Math.max(8,Math.min(80,getConfig().getInt("smoke.particles",28)));
            Location origin=p.getEyeLocation().add(p.getLocation().getDirection().multiply(0.45));
            p.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE,origin,count,0.13,0.16,0.13,0.01);
            p.getWorld().spawnParticle(Particle.SMOKE,origin,Math.max(5,count/2),0.1,0.1,0.1,0.01);
            p.getWorld().playSound(p.getLocation(),Sound.BLOCK_CAMPFIRE_CRACKLE,0.5f,1.5f);
            consumeOne(p,hand);
            p.sendMessage(ChatColor.GRAY+"Das una calada. Te mareas y notas un subidón de velocidad.");
        } else if (kind(hand).equals("leaf")) {
            // Mensaje orientativo: la receta se crea al activar el plugin.
        }
    }

    private void consumeOne(Player p, ItemStack stack) {
        if (stack==null) return;
        if (stack.getAmount()<=1) p.getInventory().setItemInMainHand(null);
        else stack.setAmount(stack.getAmount()-1);
    }
    @Override public void onDisable() { if (crops!=null) saveCrops(); }
}
